// hal yang diganti :
