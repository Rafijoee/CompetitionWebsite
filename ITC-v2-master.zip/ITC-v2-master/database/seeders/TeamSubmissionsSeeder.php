<?php

namespace Database\Seeders;

use App\Models\Teams;
use App\Models\TeamSubmissions;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TeamSubmissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    }
}
