<?php

namespace Database\Seeders;

use App\Models\SubmissionDetails;
use App\Models\SubmissionsTypes;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SubmissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        
    }
}
