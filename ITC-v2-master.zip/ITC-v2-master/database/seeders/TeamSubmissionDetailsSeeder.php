<?php

namespace Database\Seeders;

use App\Models\SubmissionsTypes;
use App\Models\TeamSubmissions;
use App\Models\TeamSubmissionsDetails;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TeamSubmissionDetailsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    }
}
